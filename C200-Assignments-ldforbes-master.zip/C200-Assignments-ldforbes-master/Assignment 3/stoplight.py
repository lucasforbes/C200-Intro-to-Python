import math
interest = 0
sum = 0
#Money
def money(d,r,t):
    interest = d * math.exp(r*t)
    return interest
print(money(1000,0.02,10))
#bacteria
def bac(n, r, t):
    sum = n * math.exp(r*t)
    return sum

print(bac(500,100,4))

#Stoplight functions
def rate(age):
    if age >= 18:
        return 4
    if 6 <= age <= 10:
        return 2
    if 11 <= age <= 15:
        return 2.5
    if 16 <= age < 18:
        return 3
    else:
        return 4
print(rate(int(input("What is your age? "))))

time = 0
def DWtime(w, r):
    time = w / r
    return time-6
print("The do not walk will flash for",DWtime(30, rate(7)),"seconds")
