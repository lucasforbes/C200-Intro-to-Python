#for loop
def maxFor(alist):
    large = alist[0]
    for i in alist:
        if i > large:
            large = i
    return large
print(maxFor([9,23,43]))

#while loop
def maxWhle(alist):
    large = alist[0]
    counter = 1
    while i < counter:
        if i > large:
            large = i
            counter = counter + 1
    return large
print(maxFor([9,23,43]))


