def EstPopSize(taggedFirst, capturedAgain, taggedSecond): 
  taggedFirst = 0
  capturedAgain = 0
  taggedSecond = 0
  e = 0
  for i in lifeData:
      taggedFirst = i[1]
      capturedAgain = i[2]
      taggedSecond = i[3]
      e = (taggedFirst * capturedAgain) / taggedSecond
      return e
lifeData = [["Bison", 20, 10, 2], ["Wolf", 10, 15, 4], ["Praire Dog", 15,15, 1]]

for d in lifeData:
    print(d[0] + " estimated population size = " + str(EstPopSize(d[1],d[2],d[3])))
