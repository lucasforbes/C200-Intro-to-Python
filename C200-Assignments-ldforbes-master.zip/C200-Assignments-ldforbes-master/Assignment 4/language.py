# Verb endings
ar = ["o", "as", "a", "amos", "ais", "an"]
er = ["o", "es", "e", "emos", "eis", "en"]

# Dictionary that allows easy access to verb endings
endings = { "ar": ar, "er": er}

# Pairs of verbs (English, Spanish)
words = [["to buy", "comprar"], ["to speak", "hablar"], ["to learn", "apprender"]]

# A function that takes the English verb and returns the Spanish verb if←↩available

def getVerb(v):
    for i in words:
        if i[0] == v:
            return i[1] 
    return " "
print(getVerb("to buy"))


# A function that gives the last two letters (ending) to determine
# # how the verb is conjugated.

def getEnding(v):
    if v =="comprar":
        return "ar"
    if v =="hablar":
        return "ar"
    if v =="apprender":
        return "er"
    else:
        return "Not in List"

print(getEnding("hablar"))


# The main function:
# Takes as input: English verb
# If it’s found in the word list, then it returns
# the Spanish; otherwise it returns [] to indicate
# the entry wasn’t found
# Finds the conjugations using the dictionary
# And returns a list of conjugations

def conjugate(v):
    if v == "to buy":
        return ["compro", "compras", "compra", "comprais", "compramos", "compran"]
    if v == "to speak":
        return  ["hablo", "hablas", "habla", "hablais", "hablamos", "hablan"]
    if v == "to learn":
        return  ["apprendo", "apprendes", "apprende", "apprendemos", "apprendeis", "apprenden"] 
    else: 
        return "Word not in List"


print(getVerb("to buy"))
print(getVerb("to see"))
print(getEnding("comprar"))
print(getEnding("aprender"))
print()
print(conjugate("to buy"))
print(conjugate("to learn"))
print(conjugate("to see"))