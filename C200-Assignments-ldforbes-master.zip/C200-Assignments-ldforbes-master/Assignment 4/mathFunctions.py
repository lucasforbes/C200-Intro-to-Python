#Implement thea(n)function asaForLoop,aWhileLoop, andaRecursive
#aForLoop
def f(n):
    for i in (n,0):
        a = 2 * (n-1) + 5
    return a 
print(f(1))

#aWhileLoop
def w(n):
    counter = 0
    while counter < n+1:
        a = 2 * (n-1) + 5
        counter = counter + 1
    return a 
print(w(1))

#aRecursive
def r(n):
    if n == 1:
        return 5
    else:
        return 2*(n-1)+5
print(r(1))


#Implement theh(n)function ashForLoop,hWhileLoop, andhRecursive
#hForLoop
def f(h):
    for i in (h,0):
        if h >= 2:
            a = (h-1) + (2 *(h-2))
            return a
        else:
            return "h is not greater than or equal to 2"
print(f(1000))

#hWhileLoop
def w(h):
    counter = 0
    while counter < (h+1):
        if h < 2:
            return "h is not greater than or equal to 2"
        else:
            a = (h-1) + (2 *(h-2))
            return a
    counter = counter + 1
print(w(1000))

#hRecursive
def r(h):
    if h < 2:
        return "h is not greater than or equal to 2"
    else:
        return (h-1) + (2 *(h-2))
print(r(1000))



#Implement thee(n)function aseForLoop,eWhileLoop, andeRecursive
#eForLoop
def f(e):
    for i in (e,0):
        a = 2 * (e-1) +2
    return a 
print(f(5))

#eWhileLoop
def w(e):
    counter = 0
    while counter < (e+1):
         a = 2 * (e-1) +2
         counter = counter + 1
    return a

print(w(5))

#eRecursive
def r(e):
    if e == 1:
        return 2
    else:
        return 2 * (e-1) +2
print(r(5))
 