def letter_to_code(letter):
    return code[letter.upper()]

def code_to_letter(code):
    return d[code]

space_between_letters = "..."

space_between_words = "......."

code = {'A':'=.===',
'B':'===.=.=.=',
'C':'===.=.===.=',
'D':'===.=.=',
'E':'=',
'F':'=.=.===.=',
'G':'===.===.=',
'H':'=.=.=.=',
'I':'=.=',
'J':'=.===.===.===',
'K':'===.=.===',
'L':'=.===.=.=',
'M':'===.===',
'N':'===.=',
'O':'===.===.===',
'P':'=.===.===.=',
'Q':'===.===.=.===',
'R':'=.===.=',
'S':'=.=.=',
'T':'===',
'U':'=.=.===',
'V':'=.=.=.===',
'W':'=.===.===',
'X':'===.=.=.===',
'Y':'===.=.===.===',
'Z':'===.===.=.='}
translation = []
def word_to_code(word):
    #TO DO 1
    ##Takes a word (string without spaces) and produces Morse code string
    translation = ""
    for i in word:
        translation = translation + letter_to_code(i) + space_between_letters
    if len(translation)>0:
        translation = translation[:len(translation) - len(space_between_letters)]

    return translation 

print(word_to_code("CAR"))

def sentence_to_code(s):
    #TO DO 2
    ##Takes a strings (words with only a single space between) and makes aMorse code string
    #splitting s into words
    #call word_to_code on each word
    s = s.split(" ")
    sentence = " "
    for i in s:
        sentence += word_to_code(i) + space_between_words
    if len(sentence)> 0:
        sentence = sentence[:len(sentence) - len(space_between_words)]
    return sentence 

    
print(sentence_to_code("the car goes fast"))

#Reverse Morse Code Dictionary CODE->LETTER
d = {}
for k,v in code.items():
    d[v] = k

def code_to_word(s):
    s = s.split(space_between_letters)
    #TO DO 3
    ##Takes a single Morse Code entry and returns the letter
    translation = ""
    for i in s:
        translation = translation + code_to_letter(i) 
    return translation 
print(code_to_word("===.=.===.=...=.===...=.===.="))

def code_to_sentence(s):
    #TO DO 4
    ##Takes a Morse code sentences and returns a string of words
    #splitting s into words
    #call code_to_word on each word
    s = s.split(space_between_words)
    translation = ""
    for i in s:
        translation += code_to_word(i) + " "
    if len(translation)> 0:
        translation = translation[:len(translation) - 1]
    return translation 
print(code_to_sentence("===...=.=.=.=...=.......===.=.===.=...=.===...=.===.=.......===.===.=...===.===.===...=...=.=.=.......=.=.===.=...=.===...=.=.=...==="))



#testing
def testing(s,c):
    if sentence_to_code(s) == c:
        print("S->C for {0} passed.".format(s))
    else:
        print("S->c for {0} failed.".format(s))
    if code_to_sentence(c) == s:
        print("C->S for {0} passed.".format(s))
    else:
        print("C->S for {0} failed.".format(s))

test_strings = ["MORSE CODE", "I NEED MONEY", "ORDER PIZZA"]
test_code = []# test strings go here

#Check for correctness
for s,c in zip(test_strings, test_code):
    testing(s,c)

#TO DO 5
#Read codes in \url{c.txt} and translate them and display them.
file = open("C:\\python\\c.txt",'r')
file = file.readlines()
for i in file:
    i = i.strip()
    print(code_to_sentence(i))
