import sys, pygame
#initializes library
pygame.init()
#creates window -- many more values can be set
size = width, height = 320, 240
black = 0, 0, 0
screen = pygame.display.set_mode(size)

#create first star (image) and bounding box
star1 = pygame.image.load("c:\\python\\star1.png")
star1rect = star1.get_rect()
#increment x += 1, y += 1
speed = [1, 1]

#create second star
star2 = pygame.image.load("c:\\python\\star2.png")
star2rect = star2.get_rect()

#create BLAM!
blam =  pygame.image.load("c:\\python\\blam.jpg")
blamrect = blam.get_rect()

#explicitly putting star location into second star
star2rect.x = 40
star2rect.y = 200
speed2 = [1,1]

while 1:
#check for any user interaction
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif pygame.key.get_pressed()[pygame.K_1]:
            print("1 pressed")
        elif pygame.key.get_pressed()[pygame.K_UP]:
            print("Up Arrow Pressed")
            speed = [speed[0] + 1, speed[1] + 1]
        elif pygame.key.get_pressed()[pygame.K_DOWN]:
            print("Down Arrow Pressed")
        elif pygame.key.get_pressed()[pygame.K_LEFT]:
            print("Left Arrow Pressed")
        elif pygame.key.get_pressed()[pygame.K_RIGHT]:
            print("Right Arrow Pressed")
            #TO DO 1
            #OMG You pressed the m key
        elif pygame.key.get_pressed()[pygame.K_m]:
            print("OMG You pressed the m key")
        

    star1rect = star1rect.move(speed)
    star2rect = star2rect.move(speed2)

#displays (x,y) of star1
    print("({0},{1})".format(star1rect.x, star1rect.y))

#make sure they objects stay within window

    if star1rect.left < 0 or star1rect.right > width:
        speed[0] = -speed[0]
    if star2rect.left < 0 or star2rect.right > width:
        speed2[0] = -speed2[0]
    if star1rect.top < 0 or star1rect.bottom > height:
        speed[1] = -speed[1]
    if star2rect.top < 0 or star2rect.bottom > height:
        speed2[1] = -speed2[1]

    screen.fill(black)

#if objects collide make their increments opposite
    if star1rect.colliderect(star2rect):
        speed[0] = - speed[0]
        speed[1] = - speed[1]
        speed2[0] = - speed2[0]
        speed2[1] = - speed2[1]
        blamrect.x = star1rect.x-(blamrect.width/2)
        blamrect.y = star1rect.y-(blamrect.height/2)
        screen.blit(blam,blamrect)


#draw objects in NEW location
    screen.blit(star1, star1rect)
    screen.blit(star2, star2rect)
#render screen
    pygame.display.flip()

    #slow down game
    pygame.time.delay(80)