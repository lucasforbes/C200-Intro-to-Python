#for loop

from timeit import default_timer as timer
import numpy as np

def fib(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    if n < 100 and n >= 2:
        x = n-1
        y = n-2
        answer = fib(x)+fib(y)
        return answer    
print(fib(5))



for n in range(1,40):
    start = timer()
    print("f({0}) = {1} took {2} seconds.".format(n, fib(n),timer()-start))


def fibForLoop(n):
    a = np.array(range(n+1),int)
    a[0] = 0
    a[1] = 1
    for i in range(2,n+1):
        a[i] = a[i-1] + a[i-2]
    return a[n]

for n in range(1,40):
    start = timer()
    print("f({0}) = {1} took {2} seconds.".format(n, fibForLoop(n),timer()-start))


# fib(10) = 5.05393
# fib(20) = 0.00446
# fib(40) = 3.2371578 e-05
# fib(80) = advised not to wait 3 days... 

# The while loop is a much faster way compared to recursion because 
# recursion has to recalculate the values say f(1-10) in order to get
# the value of f(11)
