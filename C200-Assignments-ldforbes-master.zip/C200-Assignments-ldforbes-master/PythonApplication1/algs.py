x = [2,5,3,7,8,9]

def increase(xlist):
    sml = [xlist[0]]
    lrg = [xlist[0]]
    for i in range(1,len(xlist)):
        if (xlist[i] >= xlist[i - 1]):
            sml = sml + [xlist[i]]
            if len(sml) >= len(lrg):
                lrg = sml
        else:
            sml = [xlist[i]]
    return lrg
print(increase(x))

t = [1,0,0,0,1,1,1,1,0,0,1]
def runOfOnesFor(alist):
    sml = [alist[0]]
    lrg = [alist[0]]
    for i in range(0,len(alist)):
        if alist[i] == 1:
            sml = sml + [alist[i]]
            if len(sml) >= len(lrg):
                lrg = sml
        else:
            sml =[]
    return len(lrg)
print(runOfOnesFor(t))

a = "abcd325"
b = "ftDEDc3"
def stringIntersection(xlist,ylist):
    alist = list(xlist)
    blist = list(ylist)
    emptylist = []
    for i in range(0,len(alist)):
        for a in range(0,len(blist)):
            if alist[i] == blist[a]:
                emptylist = emptylist + [alist[i]]
    return emptylist
print(stringIntersection(a,b))
