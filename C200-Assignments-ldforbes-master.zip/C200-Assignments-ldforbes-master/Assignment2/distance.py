def myDistance(s,t):
    dis = s * t
    return dis
s = int(input("how fast are you going? Mph:"))
t = int(input("how long have you been traveling? Hrs:"))
print(myDistance(s,t), "miles")

def mySpeed(d,t):
    speed = d/t
    return speed
d = int(input("how far have you traveled? Miles:"))
t = float(input("how long have you been traveling? Hrs:"))
print("you are traveling", mySpeed(d,t), "mph")





