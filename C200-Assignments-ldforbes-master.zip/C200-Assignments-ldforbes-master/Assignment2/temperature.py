
def conversion(TC):
    TF = TC * (9/5) + 32
    return TF
TC = int(input("what is the temperature in Celcius? "))  
if conversion(TC) < 45:
    print("wear a coat its", conversion(TC), "degrees fahrenheit!")
elif conversion(TC) > 90:
    print("stay hydrated its", conversion(TC), "degrees fahrenheit!")
else:
    print("it is", conversion(TC),"degrees fahrenheit")
