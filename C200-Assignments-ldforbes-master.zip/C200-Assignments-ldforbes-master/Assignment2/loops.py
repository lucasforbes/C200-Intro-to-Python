for i in range(0,4):
    print(i)
move = 0.0
while move <= 4.0:
    print(move)
    move = move + 0.1
i = 1
for i in range(i,5):
    print(i)

for kitty in range(0,(1+2)):
    print(kitty)

for Supercalifragilisticexpialidocious in range(0,1):
    print(Supercalifragilisticexpialidocious)
 
for i in range(1,12,2):
   
    print(' '*int((i)/2) + '*'*(12-i), end="")
    print()

sum=0
i=0
x=1
#loop for 1+4+9+16..-100..... 1,5,14,30......+4,+9,=16
while x<=10:
    sum = i + (x*x)
    i = sum
    x = x + 1
    print(sum)

# loop for donor dollars

donorlist = [10, 12, 0.75, 5.23, 25.35, 14.53, 15.99, 8, 8.01, 0.25]
def sumListFor(aList): #Sum all items in the list aList
    result = 0
    for item in aList:
        result = result + item
    return result
if sumListFor(donorlist) > 100:
    print("Double it!")
else:
    print("Not over $100")
print("the sum of the donations is...$",str(sumListFor(donorlist)))
