# O's best move
game = [['x','o','x'],['_','x','o'],['_','_','0']]
for row in game:
    print(row)
print("o's next best move is the bottom right corner")


#smallest value for list
x = [25, 2, 142, 0, 54, -1]
z = 100000000
for i in x:
    if i < z:
        kitty = i
print("The smallest value in x is ", str(kitty))

