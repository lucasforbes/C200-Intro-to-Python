
#balloon True
#red False
#green True
#color false

def passThroughDoor(string):
    counter = 0
    totalcount = 0
    while counter < len(string)-1:
        if string[counter] == string[counter +1]:
            return True
        counter = counter + 1
    return False
print(passThroughDoor("red"))

