def maxthree (x,y,z):
    if(x>y and x>z):
        return(x)
    elif(y>x and y>z):
        return(y)
    elif(z>y and z>x):
        return(z)
    else:
        return(x)
print(maxthree(9,2,35))

def minthree (x,y,z):
    if(x<y and x<z):
        return(x)
    elif(y<x and y<z):
        return(y)
    elif(z<y and z<x):
        return(z)
    else:
        return(x)
print(minthree(9,2,35))

def maxtwosum (x,y,z):
    if ((x+y)>(x+z) and (x+y)>(y+z)):
        return (x+y)
    elif ((x+z)>(x+y) and (x+z)>(y+z)):
        return (x+z)
    elif ((y+z)>(x+y) and (y+z)>(x+z)):
        return (y+z)
    else:
        return(x+z)
print(maxtwosum(1,2,3))

def mintwosum (x,y,z):
    if ((x+y)<(x+z) and (x+y)<(y+z)):
        return (x+y)
    elif ((x+z)<(x+y) and (x+z)<(y+z)):
        return (x+z)
    elif ((y+z)<(x+y) and (y+z)<(x+z)):
        return (y+z)
    else:
        return(x+z)
print(mintwosum(1,2,3))


def maxList(alist):
    currentMax = -9999999999999
    
    for item in alist:
        if item > currentMax:
            currentMax = item
    return(currentMax)

a = [1, 3, 2, 5]
print(maxList(a))

def minList(alist):
    currentMin = 999999999999999
    
    for item in alist:
        if item < currentMin:
            currentMin = item
    return(currentMin)

a = [1, 3, 2, 5]
print(minList(a))
