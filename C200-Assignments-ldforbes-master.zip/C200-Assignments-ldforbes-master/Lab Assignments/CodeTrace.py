def mystery(n):
    dog = []
    for cat in range(1, n + 1):
        if(cat % 2 == 0):
            dog = dog + [cat]
    return dog  

def enigma(x):
    turtle = 0 
    for kitty in x:
        turtle = turtle + kitty
    return turtle

a = int(input("#"))
something = mystery(a)
somethingElse = enigma(something)
print(somethingElse)
