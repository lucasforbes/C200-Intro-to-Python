class bookList:
    def __init__(self, title, firstName, lastName, price, quantity):
        self.title = title
        self.firstName = firstName
        self.lastName = lastName
        self.price = price
        self.quantity = quantity

    def getTitle(self):
        return self.title
    def getFirstName(self):
        return self.firstName
    def getLastName(self):
        return self.lastName
    def getPrice(self):
        return self.price
    def getQuantity(self):
        return self.quantity
    def inStock(self):
        if self.quantity > 0:
            return "Yes"
        else:
            return "No"

    def sold(self):
        if self.quantity > 0:
            return
        else:
            return "Can't sell item"
          
    def toString(self):
        return self.title + ", " + self.firstName + ", " + self.lastName + ", " + self.price + ", " + self.quantity
        

class CoffeeShop:
    def __init__(self, CoffeeList):
        self.coffeeList = coffeeList

    def coffeeSearch(drink, roast):
        combined = drink + " " + roast
        for i in self.coffeeList:
            if i.getdrink() + " " + i.getRoast == combined:
                return i

    def sale(self, coffeeSold):


class Coffee:
    def __init__(self, drink, roast, price, quantity):
        self.drink = drink
        self.roast = roast
        self.price = price
        self.quantity = quantity

    def getDrink(self):
        return self.drink
    def getRoast(self):
        return self.roast
    def getPrice(self):
        return self.price
    def getQuantity(self):
        return self.quantity
    def inStock(self):
        if self.quantity > 0:
            return True
        else:
            return False
    def sold(self):
         if self.quantity > 0:
            self.quantity -= 1
            return 
         else:
            return "Can't sell item"
    def toString(self):
        return self.drink + ", " + self.roast + ", " + self.price + ", " + self.quantity

class BookStore:
    def __init__(self, bookList, coffeeShop):
        self.bookList = bookList
        self.coffeeShop = coffeeShop

    def bookSearch(self, title):
        #takes in a title and returns the book if found
        for i in self.bookList:
            if i.getTitle() == title:
                return i

    def authorSearch(self, firstName, lastName):
        #takes in an authors name and returns the book if found
        searchauthorname = firstName + " " + lastName
        for i in self.bookList:
            if i.getFirstName() + " " + i.getLastName == searchauthorname:
                return i

    def coffeeSearch(self, drink, roast): 
        #takes in a drink and roast and returns the coffee

    def sale(self, bookSold, coffeeSold): 
        #takes in a list of books sold and list of coffees sold and returns the price





