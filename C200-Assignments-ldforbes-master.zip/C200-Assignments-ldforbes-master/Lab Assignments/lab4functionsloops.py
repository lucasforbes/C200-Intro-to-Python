L = [1, 2, 3, 4]


def sumListWhile(aList):
#sums all numbers in a list using a while loop
    listLength = len(aList)
    result = 0
    counter = 0
    while counter < listLength:
        result = result + aList[counter]
        counter = counter + 1
    return result
   
print(int(sumListWhile(L)))

def multiplyListFor(aList):
#multiply the numbers in a list together using a for-loop
    counter = 0
    result = 1
    for item in aList:
        result = result*item 
        
    return result
print(str(multiplyListFor(L)))

def factorialWhileLoop(n):
#return the factorial of n using a while-loop
    result = 1
    while n > 0:
        result = result * (n)
        n = n-1
    return result
print(str(factorialWhileLoop(4)))
#def multiplyWhile(x,y):




 