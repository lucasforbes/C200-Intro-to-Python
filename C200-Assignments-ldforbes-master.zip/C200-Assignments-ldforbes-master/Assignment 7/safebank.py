class Account:
    ID = 1
    def __init__(self, initial_deposit):
        self.balance = initial_deposit

    
    def security(self):
        Consecutive = 0
        for i in range(3):
            ID = int(input("what is your ID:  "))
            if ID == self.ID:
                Consecutive = 0
                return True
            else:
                Consecutive += 1
                if Consecutive >=3:
                    print("This account is locked. Please call.")
                    return False
# security() keeps track of the missed attempts
    def withdraw(self, amount):
        if self.security() == False:
            print("This account is locked. Please call.")
        else:
            if amount > self.balance:
                return 0
            else:
                self.balance -= amount
                return self.balance
                    
            
    def deposit(self, amount):
        if self.security() == False:
            print("This account is locked. Please call.")
        else:
            self.balance += amount
            return self.balance

    def current_balance(self):
        #ignore this method -- you can use it, 
        #but assume nobody can access it.
        return self.balance

class Bank(Account):
    def __init__(self,name,initial_deposit):
        
        self.name = name
        Account.__init__(self,initial_deposit)
        self.ID = Account.ID
        Account.ID += 1
        self.locked_out = False
    def __str__(self):
        return "Name: {0} ID: {1} Balance: {2}".format(self.name, self.ID, self.current_balance())

    def get_balance(self):
        if self.security() == True:
            return self.balance
       # don't need else statements because of security check
x1 = Bank("Kaiser", 100)
x2 = Bank("Ursala", 200)
x3 = Bank("Shilah", 75)


print(x3.deposit(50))



