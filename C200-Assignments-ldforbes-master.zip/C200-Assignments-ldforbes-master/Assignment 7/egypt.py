import webbrowser

def egypt(x):
    d = " "
    for i in translation(name):
        d = d + '<img src="C:\\python\\eglyph$.jpg"><br>'.replace("$",i)
        
           
    s = "<html><head></head>"
    a = "<body>"
    b = "<h2 class='text-center'>{0} = {1}</h2>".format(name,translation(name))
    c = "<img src='C:\\python\\eglyphTOP.jpg'><br>"
    y = "<img src='C:\\python\\eglyphBOTTOM.jpg'><br>"
    z = "</body></html>"
    f = s+a+b+c+d+y+z
    return f



#ask user for location of file to be created
plocation = input("Enter location: ")


f = open(plocation,'w')
name = input("Name: ")
def translation(name):
    translation = ""
    for i in name:
        if i == "e" or i == "f":
            translation = translation
        else:
            translation += i
    return translation
# translation function takes letters that don't have 
# corresponding pictures and removes them

            
#Write the HTML to the file
f.write(egypt(name))
##Close
f.close()
##Display it from within Python
webbrowser.open_new_tab(plocation)
