Ta =float(input("What is the temperature? "))
V=float(input("What is the wind speed? "))
Twa=(34.74 + (Ta*0.6215)-((35.75)*(V**0.16))+((0.4275*Ta)*(V**0.16)))
print(Twa)