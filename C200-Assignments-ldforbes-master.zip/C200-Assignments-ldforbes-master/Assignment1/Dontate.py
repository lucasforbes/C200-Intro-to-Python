bloodtype=input("What is your blood type? (A+, A-, B+, B-, AB+, AB-, O+, O-")
if(bloodtype == "A+"):
    print("You can donate to A+ or AB+")
elif(bloodtype == "AB+"):
    print("You can donate to AB+")
elif(bloodtype == "O-"):
    print("You can donate to anyone")
elif(bloodtype == "B+"):
    print("You can donate to B+ or AB+")
elif(bloodtype == "A-"):
    print("You can donate to A-, A+, AB-, AB+")
elif(bloodtype == "AB-"):
    print("You can donate to AB-, AB+")
elif(bloodtype == "O+"):
    print("You can donate to O+, A+, B+, AB+")
elif(bloodtype == "B-"):
    print("You can donate to B-, B+, AB-, AB+")
else:
    print("You don’t have a recognized bloodtype!Get to a doctor now.")