Income=int(input("What is your income?"))
Taxes=(Income*(25/100))
if(Income > 37950 and Income < 91899):
    print(Taxes)
else:
    print("You are in a different tax bracket")

Taxespaid=int(input("How much did you pay in taxes? "))
Income=(Taxespaid/.25)
if(Income>37950 and Income < 91899):
    print(Income)
else:
    print("Your amount paid in taxes put you in a different tax bracket")
