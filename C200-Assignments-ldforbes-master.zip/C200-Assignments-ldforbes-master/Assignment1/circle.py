import math
radius = input("Enter the radius of the circle: ")
radius = int(radius)
print("The area of a circle is " + str((radius**2)*math.pi))