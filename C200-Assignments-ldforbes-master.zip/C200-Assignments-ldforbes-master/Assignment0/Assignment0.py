
print("Hello World")