def addition (x, y):
    z = x + y
    return z
print(addition(3,5))

def subtraction (x, y):
    z = x-y
    return z
print(subtraction(10,7))

def max(x,y):
    if (x>y):
        return x
    elif (x<y):
        return y
    else: 
        return x
print(max(199,3948))

def min(x,y):
    if (x>y):
        return y
    elif (x<y):
        return x
    else:
        return x
print(min(3849,248))    

def welcome(x):
    print("This is the Message"+x)
welcome(" Lucas")

x = addition(5,3) #8
y = addition(4,3) #7
print(subtraction(x,y))

print(subtraction(addition(5,3), addition(4,3)))
