from car import car
"""from a python module called Car(.py),
only import the class Car"""


class Sedan(car):
    def __init__(self, make, model, year):
        car.__init__(self, make, model, year)
        self.doorCount = 4

    def getDoorCount(self):
        return self.doorCount

    def __repr__(self):
        return self.stringRep() + "door Count: " + str(self.doorCount)
class Minivan(car):
    def __init__ (self, make, model, year):
        car.__init__(make, model, year)
        self.doorCount = 4

    def getDoorCount(self):
        return self.doorCount

    def __repr__(self):
        return self.stringRep() + "door Count: " + str(self.doorCount)

class Truck(car):
    """constructor that takes in a make, model, year, and door count for a truck"""
    def __init__(self, make, model, year, doorCount):
        car.__init__(self, make, model, year)
        self.doorCount = doorCount

    def getDoorCount(self):
        return self.doorCount

    def __repr__(self):
        return self.stringRep() + "door Count: " + str(self.doorCount)
