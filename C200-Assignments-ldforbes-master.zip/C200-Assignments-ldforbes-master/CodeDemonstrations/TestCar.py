from body import Sedan, Minivan, Truck

honda1 = Sedan("Honda", "Accord", 2008)
toyota1 = Sedan("Toyota", "Camry", 2009)
ford1 = Truck("Ford", "f150", 2012, 4)

oldCar = honda1.olderCar(ford1)
print(oldCar)

print(honda1)
print(toyota1)
print(ford1)