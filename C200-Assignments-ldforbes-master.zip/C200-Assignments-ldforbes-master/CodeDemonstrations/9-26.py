
def ff(n):
    sum = 1
    counter = 1
    while counter < n + 1:
        sum = sum * counter
        counter = counter + 1
    return sum
print(ff(5))


"""ef fr(x,n):
    if n == 0:
        return 1
    else: 
        return fr(x*n,n-1)
print(fr(1,1000))
"""

x = [9,14,24,7,9,24]
def rf(xlist, y):
    tmp = []
    for i in xlist:
        if not (i == y):
            tmp = tmp + [i]
    return tmp
print(rf(x,24))
      
