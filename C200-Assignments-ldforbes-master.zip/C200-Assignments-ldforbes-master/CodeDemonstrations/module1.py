def m(s):
    if s:
        return s[0] == s[-1] and m(s[1:-1])
    else:
        return True

x = ["kitty", "amanaplanpanama", "atoyota", "ratsliveonnoevilstar"]

for i in x:
    print(m(i))
b = [1,2,3,4,5,6,7,8]
def rf(xlst):
    xt = []
    for i in xlst:
        if not (i%2 == 0):
            xt = xt + [i]
        i = i + 1
    return xt
print(rf(b))