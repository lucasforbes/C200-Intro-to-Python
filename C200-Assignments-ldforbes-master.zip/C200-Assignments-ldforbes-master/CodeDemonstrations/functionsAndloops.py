pie = [1,2,3,5]

def sumListFor(aList): #Sum all items in the list aList
    result = 0
    for item in aList:
        result = result + item
    return result
   
print(str(sumListFor(pie)))

a = 0 
while a < 5:
    a = a + 1
print(a)

def multiplyListWhile(aList): 
    #takes in list, returns all list items multiplied together
    listLength = len(aList)
    result = 1
    counter = 0
    while counter < listLength:
        result = result * aList[counter]
        counter = counter + 1
    return result
print(str(multiplyListWhile(pie)))

def factorialForLoop(n):
    result = 1 
    for i in range(1,n+1):
        result = result * i
    return result

print(str(factorialForLoop(5)))
