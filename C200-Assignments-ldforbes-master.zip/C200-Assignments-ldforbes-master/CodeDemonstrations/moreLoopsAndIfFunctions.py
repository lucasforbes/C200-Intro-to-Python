import math

stringList = ["red", "blue", "green", "yellow", "brown"]
"""
def middleCharacter(string):
    strLen = len(string)
    middleOfStr = int(math.floor(strLen/2)  
    return string[middleOfStr]
print(middleCharacter("green"))

def getMiddleCharacterList(alist):
    string = ""
    for i in range(0, len(alist)):
        currentStr = alist[i]
        middleChar = middleCharacter(currentStr)
        string = string + middleChar
        print(string)
    return string
print(getMiddleCharacterList(stringList))

def getLetterCount(string, character):
    counter = 0
    totalcount = 0
    while counter < len(string):
        print(string[counter])
        counter = counter + 1
print(getLetterCount("green", "e"))
"""

def getStringCount(string1, string2):
    counter = 0
    totalcount = 0
    while counter < len(string1) - len(string2) + 1:
        print(string1[counter:counter + len(string2)])
        if string1[counter:counter + len(string2) == string2]:
            totalcount = totalcount + 1
        counter = counter + 1
    return totalcount
print(getStringCount("catipillar", "cat"))
