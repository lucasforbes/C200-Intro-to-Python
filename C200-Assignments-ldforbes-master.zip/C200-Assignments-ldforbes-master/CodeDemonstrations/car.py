class car:
    """represents a car, holding the make, model, and
    year for a given car
    < Represents a string describing the general information of the class
    """
    def __init__(self, make, model, year):
        """constructor that takes in the make, model, and year"""
        self.make = make
        self.model = model
        self.year = year

    def getMake(self):
        return self.make

    def getModel(self):
        return self.model

    def getYear(self):
        return self.year

    def setYear(self, year):
        self.year = year

    def olderCar(self, otherCar):
        """returns the instance of the older car. 
        Parameter is another car class"""
        if self.year < otherCar.year:
            return self
        else:
            return otherCar

    def stringRep(self):
        return "make: " + self.make + "model: " + self.model + "year: " + str(self.year)

    def __repr__(self):
        return self.stringRep()




