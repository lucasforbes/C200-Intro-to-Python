sum = 0
for i in range(5,21):
    sum = sum + i**2 - i
print(sum)
def s(i):
    if i < 21:
        return i**2 - i +s(i+1)
    else:
        return 0
print(s(5))