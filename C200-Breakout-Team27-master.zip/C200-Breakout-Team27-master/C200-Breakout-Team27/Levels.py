class Levels:

    def __init__(self):
        pass

    def one(self):
        return (1, 10, 500, 30)

    def two(self):
        return (2, 10, 1000, 50)

    def three(self):
        return (3, 10, 1500, 70)

    def four(self):
        return (4, 10, 2000, 90)

    def fiveUp(self):
        return (5, 10, 2500, 110)
